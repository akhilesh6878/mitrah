<?php
$themeName = 'WoWonder';

$themeFolder = 'wowonder';

$themeAuthor = 'Deen Doughouz';

$themeAuthorUrl = 'mailto:wowondersocial@gmail.com';

$themeVirsion = '1.5.2';

$themeImg = $themeFolder . '/themeLogo.png';
?>